package com.tsti.servicios;

import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tsti.accesoADatos.ClientesDAO;
import com.tsti.entidades.Cliente;
import com.tsti.entidades.Persona;
import com.tsti.exception.Excepcion;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validator;

@Service
public class ClientesServiceImpl implements ClientesService{
	@Autowired
	private Validator validator;
	
	@Autowired
	private ClientesDAO dao;

	@Override
	public List<Cliente> getAll() {
		// TODO Auto-generated method stub
		return dao.findAll();
	}

	@Override
	public Optional<Cliente> getById(Long id) {
		// TODO Auto-generated method stub
		return dao.findById(id);
	}

	@Override
	public void update(Cliente p) {
		// TODO Auto-generated method stub
		dao.save(p);
	}

	@Override
	public void insert(Cliente p) throws Exception {
		
		Set<ConstraintViolation<Cliente>> cv = validator.validate(p);
		if(cv.size()>0)
		{
			String err="";
			for (ConstraintViolation<Cliente> constraintViolation : cv) {
				err+=constraintViolation.getPropertyPath()+": "+constraintViolation.getMessage()+"\n";
			}
			throw new Excepcion(err,400);
		}
		else if(getById(p.getDni()).isPresent())
		{
			throw new Excepcion("Ya existe un cliente con ese dni.",400);
		}
		else
			dao.save(p);
	}

	@Override
	public void delete(Long id) {
		// TODO Auto-generated method stub
		dao.deleteById(id);
	}

}
