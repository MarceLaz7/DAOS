package com.tsti.dto;

import java.time.LocalDate;

import org.springframework.hateoas.RepresentationModel;

import com.tsti.entidades.Cliente;

public class ClienteResponseDTO extends RepresentationModel<ClienteResponseDTO>{
	private Long dni;
	private String nombre;
	private String apellido;
	private String domicilio;
	private String email;
	private LocalDate fechaNacimiento;
	private String numeroPasaporte;
	private LocalDate fechaVenPasaporte;
	
	public ClienteResponseDTO(Cliente pojo) {
		this.dni = pojo.getDni();
		this.nombre = pojo.getNombre();
		this.apellido = pojo.getApellido();
		this.domicilio = pojo.getDomicilio();
		this.email = pojo.getEmail();
		this.fechaNacimiento = pojo.getFechaNacimiento();
		this.numeroPasaporte = pojo.getNumeroPasaporte();
		this.fechaVenPasaporte = pojo.getFechaVenPasaporte();
	}

	public Long getDni() {
		return dni;
	}

	public void setDni(Long dni) {
		this.dni = dni;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public String getDomicilio() {
		return domicilio;
	}

	public void setDomicilio(String domicilio) {
		this.domicilio = domicilio;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public LocalDate getFechaNacimiento() {
		return fechaNacimiento;
	}

	public void setFechaNacimiento(LocalDate fechaNacimiento) {
		this.fechaNacimiento = fechaNacimiento;
	}

	public String getNumeroPasaporte() {
		return numeroPasaporte;
	}

	public void setNumeroPasaporte(String numeroPasaporte) {
		this.numeroPasaporte = numeroPasaporte;
	}

	public LocalDate getFechaVenPasaporte() {
		return fechaVenPasaporte;
	}

	public void setFechaVenPasaporte(LocalDate fechaVenPasaporte) {
		this.fechaVenPasaporte = fechaVenPasaporte;
	}

	@Override
	public String toString() {
		return "ClienteResponseDTO [dni=" + dni + ", nombre=" + nombre + ", apellido=" + apellido + ", domicilio="
				+ domicilio + ", email=" + email + ", fechaNacimiento=" + fechaNacimiento + ", numeroPasaporte="
				+ numeroPasaporte + ", fechaVenPasaporte=" + fechaVenPasaporte + "]";
	}
}
