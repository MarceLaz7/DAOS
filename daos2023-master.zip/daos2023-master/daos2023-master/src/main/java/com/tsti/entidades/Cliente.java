package com.tsti.entidades;

import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

@Entity
public class Cliente {
	@Id
	private Long dni;
	
	private String nombre;
	
	@NotNull
	@Size(min = 1,max = 100, message = "Debe completar el apellido")
	private String apellido;
	
	private String domicilio;
	
	@Email(message = "El e-mail ingresado no es valido")
	private String email;
	
	private LocalDate fechaNacimiento;
	
	private String numeroPasaporte;
	
	private LocalDate fechaVenPasaporte;

	public Long getDni() {
		return dni;
	}

	public void setDni(Long dni) {
		this.dni = dni;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public String getDomicilio() {
		return domicilio;
	}

	public void setDomicilio(String domicilio) {
		this.domicilio = domicilio;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public LocalDate getFechaNacimiento() {
		return fechaNacimiento;
	}

	public void setFechaNacimiento(LocalDate fechaNacimiento) {
		this.fechaNacimiento = fechaNacimiento;
	}

	public String getNumeroPasaporte() {
		return numeroPasaporte;
	}

	public void setNumeroPasaporte(String numeroPasaporte) {
		this.numeroPasaporte = numeroPasaporte;
	}

	public LocalDate getFechaVenPasaporte() {
		return fechaVenPasaporte;
	}

	public void setFechaVenPasaporte(LocalDate fechaVenPasaporte) {
		this.fechaVenPasaporte = fechaVenPasaporte;
	}

	@Override
	public String toString() {
		return "Cliente [dni=" + dni + ", nombre=" + nombre + ", apellido=" + apellido + ", domicilio=" + domicilio
				+ ", email=" + email + ", fechaNacimiento=" + fechaNacimiento + ", numeroPasaporte=" + numeroPasaporte
				+ ", fechaVenPasaporte=" + fechaVenPasaporte + "]";
	}
}
