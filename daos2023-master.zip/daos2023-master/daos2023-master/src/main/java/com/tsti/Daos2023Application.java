package com.tsti;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Daos2023Application {

	public static void main(String[] args) {
		SpringApplication.run(Daos2023Application.class, args);
	}

}
