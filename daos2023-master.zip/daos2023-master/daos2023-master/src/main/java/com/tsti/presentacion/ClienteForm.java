package com.tsti.presentacion;

import java.time.LocalDate;

import com.tsti.entidades.Cliente;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public class ClienteForm {
	
	@NotNull(message = "el dni no puede ser nulo")
	@Min(7000000)
	private Long dni;
	
	@NotNull
	@Size(min=2, max=30)
	private String nombre;
	
	@NotNull
	@Size(min=2, max=30, message = "apellido demasiado largo")
	private String apellido;
	
	@NotNull
	@Size(min=2, max=250)
	private String domicilio;
	
	@NotNull
	@Size(min=2, max=100)
	private String email;
	
	@NotNull
	private LocalDate fechaNacimiento;
	
	@NotNull
	private String numeroPasaporte;
	
	@NotNull
	private LocalDate fechaVenPasaporte;

	public Long getDni() {
		return dni;
	}

	public void setDni(Long dni) {
		this.dni = dni;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public String getDomicilio() {
		return domicilio;
	}

	public void setDomicilio(String domicilio) {
		this.domicilio = domicilio;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public LocalDate getFechaNacimiento() {
		return fechaNacimiento;
	}

	public void setFechaNacimiento(LocalDate fechaNacimiento) {
		this.fechaNacimiento = fechaNacimiento;
	}

	public String getNumeroPasaporte() {
		return numeroPasaporte;
	}

	public void setNumeroPasaporte(String numeroPasaporte) {
		this.numeroPasaporte = numeroPasaporte;
	}

	public LocalDate getFechaVenPasaporte() {
		return fechaVenPasaporte;
	}

	public void setFechaVenPasaporte(LocalDate fechaVenPasaporte) {
		this.fechaVenPasaporte = fechaVenPasaporte;
	}
	
	public Cliente toPojo()
	{
		Cliente c = new Cliente();
		c.setDni(this.getDni());
		c.setNombre(this.getNombre());
		c.setApellido(this.getApellido());
		c.setDomicilio(this.getDomicilio());
		c.setEmail(this.getEmail());
		c.setFechaNacimiento(this.getFechaNacimiento());
		c.setNumeroPasaporte(this.getNumeroPasaporte());
		c.setFechaVenPasaporte(this.getFechaVenPasaporte());
		return c;
	}
}
