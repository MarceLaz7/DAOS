package com.tsti.servicios;

import java.util.List;
import java.util.Optional;

import com.tsti.entidades.Cliente;

public interface ClientesService {

	public List<Cliente> getAll();

	public Optional<Cliente> getById(Long id);

	public void update(Cliente p);

	public void insert(Cliente p) throws Exception;

	public void delete(Long id);

}
