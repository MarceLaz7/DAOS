package com.tsti.accesoADatos;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tsti.entidades.Cliente;

public interface ClientesDAO extends JpaRepository<Cliente, Long>{

}
